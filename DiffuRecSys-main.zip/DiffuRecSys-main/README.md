# DiffuRecSys
A Diffusion Model for Sequential Recommendation
